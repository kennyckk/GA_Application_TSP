The code for each task is divided into individual py file e.g task1.py
Please run the python files directly in the folder after unzipped since it depends on the current directory to access the data.

The code is implemented by python 3.9.12 and is built with below main packages:
geatpy 2.7.0
scikit-learn 1.0.2 (in task3)
numpy 1.21.5
matplotlib 3.5.1

***Please do not change the data folder location.***